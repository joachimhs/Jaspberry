#!/bin/bash

jarfile=jaspberry-0.0.1-jar-with-dependencies.jar
export JAVA_OPTS="-Dlog4j.configuration=file:///home/pi/jaspberry/log4j.xml"

#####

currdir=`pwd`

java $JAVA_OPTS -classpath .:classes:/opt/pi4j/lib/'*':$jarfile no.haagensoftware.netty.server.Main